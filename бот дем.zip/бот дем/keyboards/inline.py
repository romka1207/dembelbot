from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

def get_main_menu_keyboard():
    builder = InlineKeyboardBuilder()
    builder.add(InlineKeyboardButton(text="⏰ Сколько осталось?", callback_data="countdown"))
    builder.add(InlineKeyboardButton(text="😊 Оценить настроение", callback_data="mood"))
    builder.add(InlineKeyboardButton(text="✉️ Написать ему", callback_data="secret"))
    builder.add(InlineKeyboardButton(text="📊 Мой календарь", callback_data="chart"))
    builder.add(InlineKeyboardButton(text="📅 По дате", callback_data="mood_by_date"))
    builder.add(InlineKeyboardButton(text="💌 Случайная фраза", callback_data="phrase"))
    builder.adjust(2)
    return builder.as_markup()

def get_mood_keyboard():
    builder = InlineKeyboardBuilder()
    builder.add(InlineKeyboardButton(text="😢", callback_data="mood_1"))
    builder.add(InlineKeyboardButton(text="🙁", callback_data="mood_2"))
    builder.add(InlineKeyboardButton(text="😐", callback_data="mood_3"))
    builder.add(InlineKeyboardButton(text="🙂", callback_data="mood_4"))
    builder.add(InlineKeyboardButton(text="😍", callback_data="mood_5"))
    builder.adjust(5)
    return builder.as_markup()

def get_chart_period_keyboard():
    builder = InlineKeyboardBuilder()
    builder.add(InlineKeyboardButton(text="📅 Неделя", callback_data="chart_7"))
    builder.add(InlineKeyboardButton(text="📅 Месяц", callback_data="chart_30"))
    builder.add(InlineKeyboardButton(text="📅 Всё время", callback_data="chart_all"))
    builder.adjust(3)
    return builder.as_markup()

def get_cancel_keyboard():
    builder = InlineKeyboardBuilder()
    builder.add(InlineKeyboardButton(text="❌ Отмена", callback_data="cancel"))
    return builder.as_markup()
