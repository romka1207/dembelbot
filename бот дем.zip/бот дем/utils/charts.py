from datetime import datetime, timedelta
from typing import List, Dict
import logging

logger = logging.getLogger(__name__)

def create_emoji_calendar(mood_data: List[Dict]) -> str:
    if not mood_data:
        return "📊 Пока нет данных. Начни оценивать настроение! 😊"
    
    mood_emojis = {1: "😢", 2: "🙁", 3: "😐", 4: "🙂", 5: "😍"}
    
    # Группируем по датам
    dates_dict = {}
    for entry in mood_data:
        date = entry['date']
        mood = entry['mood']
        if date not in dates_dict:
            dates_dict[date] = []
        dates_dict[date].append(mood)
    
    # Сортируем даты
    sorted_dates = sorted(dates_dict.keys())
    
    # Создаём календарь
    result = "📅 Календарь настроения:\n\n"
    
    for date in sorted_dates:
        moods = dates_dict[date]
        avg_mood = sum(moods) / len(moods)
        emoji = mood_emojis.get(round(avg_mood), "😐")
        
        # Форматируем дату
        date_obj = datetime.strptime(date, '%Y-%m-%d')
        date_str = date_obj.strftime('%d.%m')
        
        # Показываем все оценки за день
        mood_str = " ".join([mood_emojis.get(m, "😐") for m in moods])
        
        result += f"{date_str}: {mood_str} ({len(moods)} запис{'ь' if len(moods) == 1 else 'и' if len(moods) in [2,3,4] else 'ей'})\n"
    
    # Статистика
    total_entries = sum(len(dates_dict[d]) for d in dates_dict)
    avg_all = sum(sum(dates_dict[d]) for d in dates_dict) / total_entries if total_entries > 0 else 0
    avg_emoji = mood_emojis.get(round(avg_all), "😐")
    
    result += f"\n📊 Статистика:\n"
    result += f"Всего записей: {total_entries}\n"
    result += f"Среднее настроение: {avg_emoji} ({avg_all:.1f}/5)\n"
    result += f"Дней с записями: {len(sorted_dates)}\n"
    
    return result

def get_mood_by_date(mood_data: List[Dict], target_date: str) -> str:
    mood_emojis = {1: "😢", 2: "🙁", 3: "😐", 4: "🙂", 5: "😍"}
    
    # Фильтруем по дате
    day_entries = [e for e in mood_data if e['date'] == target_date]
    
    if not day_entries:
        return f"📅 За {target_date} нет записей."
    
    moods = [e['mood'] for e in day_entries]
    avg_mood = sum(moods) / len(moods)
    avg_emoji = mood_emojis.get(round(avg_mood), "😐")
    
    mood_str = " ".join([mood_emojis.get(m, "😐") for m in moods])
    
    result = f"📅 Настроение за {target_date}:\n\n"
    result += f"Записи: {mood_str}\n"
    result += f"Среднее: {avg_emoji} ({avg_mood:.1f}/5)\n"
    result += f"Всего записей: {len(moods)}\n"
    
    return result
