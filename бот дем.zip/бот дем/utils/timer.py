from datetime import datetime, timedelta
import config

def get_time_passed_and_remaining():
    now = datetime.now()
    departure = config.DEPARTURE_DATE
    return_date = config.RETURN_DATE
    
    if now < departure:
        time_passed = timedelta(0)
        time_remaining = return_date - departure
    elif now > return_date:
        time_passed = return_date - departure
        time_remaining = timedelta(0)
    else:
        time_passed = now - departure
        time_remaining = return_date - now
    
    total_time = return_date - departure
    return time_passed, time_remaining, total_time

def format_timedelta(td: timedelta) -> str:
    total_seconds = int(td.total_seconds())
    days = total_seconds // 86400
    hours = (total_seconds % 86400) // 3600
    minutes = (total_seconds % 3600) // 60
    
    parts = []
    if days > 0:
        parts.append(f"{days} дн.")
    if hours > 0:
        parts.append(f"{hours} ч.")
    if minutes > 0 or not parts:
        parts.append(f"{minutes} мин.")
    
    return " ".join(parts)

def get_progress_bar(time_passed: timedelta, total_time: timedelta, width: int = 20) -> str:
    if total_time.total_seconds() == 0:
        return "[�����������������] 100%"
    
    progress = time_passed.total_seconds() / total_time.total_seconds()
    filled = int(progress * width)
    empty = width - filled
    bar = "�" * filled + "⬜" * empty
    percentage = int(progress * 100)
    return f"[{bar}] {percentage}%"

def format_countdown():
    time_passed, time_remaining, total_time = get_time_passed_and_remaining()
    progress_bar = get_progress_bar(time_passed, total_time)
    passed_bar = get_passed_bar(time_passed, total_time)
    
    passed_str = format_timedelta(time_passed)
    remaining_str = format_timedelta(time_remaining)
    
    if time_remaining.total_seconds() == 0:
        return f"🎉 Я уже вернулся!\n\n{progress_bar}"
    elif time_passed.total_seconds() == 0:
        return f"⏳ Я ещё не уехал\n\n⏳ До отъезда: {remaining_str}\n\n{progress_bar}"
    else:
        return (
            f"⏰ Прошло: {passed_str}\n{passed_bar}\n\n"
            f"🗓️ Осталось: {remaining_str}\n{progress_bar}"
        )

def get_passed_bar(time_passed: timedelta, total_time: timedelta, width: int = 20) -> str:
    if total_time.total_seconds() == 0:
        return "[🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩] 100%"
    
    progress = time_passed.total_seconds() / total_time.total_seconds()
    filled = int(progress * width)
    empty = width - filled
    bar = "🟩" * filled + "⬜" * empty
    percentage = int(progress * 100)
    return f"[{bar}] {percentage}%"
