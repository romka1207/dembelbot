# 🚀 Инструкция по деплою бота на Render.com

## Подготовка проекта

### 1. Создайте файл `Procfile` в корне проекта

Создай файл с именем `Procfile` (без расширения) в корне проекта:

```
web: python bot.py
```

### 2. Проверь `requirements.txt`

Убедись, что `requirements.txt` содержит все зависимости:

```
aiogram==3.13.1
python-dotenv==1.0.1
matplotlib==3.9.2
```

### 3. Создай файл `.gitignore`

Убедись, что `.gitignore` содержит:

```
.env
*.db
__pycache__/
*.pyc
.DS_Store
data/photos/*
!data/photos/.gitkeep
```

### 4. Измени `bot.py` для работы с вебхуком

Замени содержимое `bot.py` на это (для работы с вебхуком вместо polling):

```python
import asyncio
import logging
import os
from aiogram import Bot, Dispatcher
from aiogram.filters import Command
from aiogram.types import Update
from aiogram.webhook.aiohttp import AiohttpWebhook
from aiohttp import web
import config
import sys

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

bot = Bot(token=config.BOT_TOKEN)
dp = Dispatcher()

from handlers import start, countdown, mood, diary, secret, content, owner

dp.include_router(start.router)
dp.include_router(countdown.router)
dp.include_router(mood.router)
dp.include_router(diary.router)
dp.include_router(secret.router)
dp.include_router(content.router)
dp.include_router(owner.router)

WEBHOOK_HOST = os.getenv('WEBHOOK_HOST', 'localhost')
WEBHOOK_PORT = int(os.getenv('WEBHOOK_PORT', 8080))
WEBHOOK_PATH = os.getenv('WEBHOOK_PATH', '/webhook')

async def on_startup(bot):
    await bot.set_webhook(f"{WEBHOOK_HOST}{WEBHOOK_PATH}")
    logger.info(f"Webhook set to {WEBHOOK_HOST}{WEBHOOK_PATH}")

async def on_shutdown(bot):
    await bot.delete_webhook()
    logger.info("Webhook deleted")

async def process_update(request):
    update = await request.json()
    await dp.feed_update(bot, Update(**update))
    return web.Response(status=200)

async def main():
    app = web.Application()
    app.router.add_post(WEBHOOK_PATH, process_update)
    
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, host='0.0.0.0', port=WEBHOOK_PORT)
    await site.start()
    
    logger.info(f"Server started on port {WEBHOOK_PORT}")
    
    try:
        await dp.start_polling(bot)
    finally:
        await runner.cleanup()

if __name__ == "__main__":
    asyncio.run(main())
```

## Деплой на Render.com

### Шаг 1: Регистрация на Render

1. Перейди на [render.com](https://render.com)
2. Нажми "Sign Up" и зарегистрируйся через GitHub (рекомендуется)

### Шаг 2: Создай репозиторий на GitHub

1. Зайди на [github.com](https://github.com)
2. Создай новый репозиторий (например, `love-bot`)
3. Загрузи туда все файлы проекта:
   ```bash
   cd "/Users/romanstepanov/Desktop/бот дем"
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/ТВОЙ_ЮЗЕРНЕЙМ/love-bot.git
   git push -u origin main
   ```

### Шаг 3: Создай Web Service на Render

1. В панели Render нажми **"New +"** → **"Web Service"**
2. Подключи свой GitHub репозиторий
3. Выбери репозиторий `love-bot`
4. Настрой параметры:

**Build & Deploy:**
- **Runtime**: Python 3
- **Build Command**: `pip install -r requirements.txt`
- **Start Command**: `python bot.py`

**Environment:**
Добавь переменные окружения (раздел "Environment Variables"):
```
BOT_TOKEN=8925920135:AAHs7oZy9R4bqUz9LDqGwsy3YlhWlPvB1Ho
OWNER_USERNAME=RomkaStp
DEPARTURE_DATE=2026-06-28 22:00
RETURN_DATE=2026-08-02
DAILY_SCHEDULE_1=09:00
DAILY_SCHEDULE_2=20:00
WEBHOOK_HOST=https://твой-бот.onrender.com
WEBHOOK_PATH=/webhook
```

**Advanced:**
- **Instance Type**: Free (бесплатно)

5. Нажми **"Create Web Service"**

### Шаг 4. Получи URL вебхука

1. После деплоя Render покажет URL: `https://твой-бот.onrender.com`
2. Скопируй этот URL

### Шаг 5. Настрой вебхук в Telegram

Открой в браузере:
```
https://api.telegram.org/bot8925920135:AAHs7oZy9R4bqUz9LDqGwsy3YlhWlPvB1Ho/setWebhook?url=https://твой-бот.onrender.com/webhook
```

Если всё правильно, увидишь:
```json
{"ok":true,"result":true,"description":"Webhook was set"}
```

## Проверка работы

1. Открой Telegram и напиши `/start` боту
2. Бот должен ответить с главным меню
3. Проверь все функции

## Важно о бесплатном тарифе Render

**Ограничения бесплатного тарифа:**
- Бот "спит" через 15 минут неактивности
- Просыпается за ~30 секунд при новом сообщении
- 750 часов работы в месяц (хватает на 24/7)
- Рестарт каждые 24 часа (Render автоматически перезапускает)

**Для бота это нормально:**
- Девушка пишет → бот просыпается → отвечает
- Нет задержек для обычного использования
- Ежедневная рассылка будет работать

## Если бот не отвечает

1. Проверь логи в Render (вкладка "Logs")
2. Убедись, что вебхук настроен правильно:
   ```
   https://api.telegram.org/bot8925920135:AAHs7oZy9R4bqUz9LDqGwsy3YlhWlPvB1Ho/getWebhookInfo
   ```
3. Проверь переменные окружения в Render

## Обновление бота

Чтобы обновить бота:
1. Измени код локально
2. Запусти:
   ```bash
   git add .
   git commit -m "Update bot"
   git push
   ```
3. Render автоматически перезапустит бота

## Удаление вебхука (если нужно)

```
https://api.telegram.org/bot8925920135:AAHs7oZy9R4bqUz9LDqGwsy3YlhWlPvB1Ho/deleteWebhook
```
