from aiogram import Router, F
from aiogram.filters import StateFilter
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from keyboards.inline import get_cancel_keyboard, get_main_menu_keyboard
from database import db
import config

router = Router()

class SecretStates(StatesGroup):
    waiting_for_message = State()
    waiting_for_photo = State()

@router.callback_query(F.data == "secret")
async def request_secret_message(callback: CallbackQuery, state: FSMContext):
    await state.set_state(SecretStates.waiting_for_message)
    await callback.message.edit_text(
        "✉️ Напиши весточку для меня...\n\n"
        "Твоё сообщение сохранится и я прочитаю его, когда вернусь. "
        "Можно добавить фото!",
        reply_markup=get_cancel_keyboard()
    )
    await callback.answer()

@router.message(StateFilter(SecretStates.waiting_for_message))
async def process_secret_message(message: Message, state: FSMContext):
    user_id = message.from_user.id
    text = message.text or message.caption or ""
    photo_id = None
    
    if message.photo:
        photo_id = message.photo[-1].file_id
    
    if not text and not photo_id:
        await message.answer("Пожалуйста, отправь текст или фото.")
        return
    
    db.add_secret_message(user_id, text, photo_id)
    
    # Пересылка владельцу
    try:
        from aiogram.types import User
        owner_username = config.OWNER_USERNAME
        
        # Получаем ID владельца через username (нужно будет добавить функцию)
        # Временно просто логируем
        import logging
        logger = logging.getLogger(__name__)
        logger.info(f"Сообщение от {user_id} для {owner_username}: {text[:50]}...")
        
        # TODO: Добавить реальную пересылку когда будет ID владельца
    except Exception as e:
        import logging
        logger = logging.getLogger(__name__)
        logger.error(f"Ошибка при пересылке: {e}")
    
    await state.clear()
    response = "Весточка сохранена! ✉️\n\n"
    if photo_id:
        response += "Я обязательно посмотрю фото, когда вернусь! ❤️"
    else:
        response += "Я обязательно прочитаю, когда вернусь! ❤️"
    
    await message.answer(response, reply_markup=get_main_menu_keyboard())

@router.callback_query(F.data == "cancel", StateFilter(SecretStates.waiting_for_message))
async def cancel_secret_message(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text("Отменено.", reply_markup=get_main_menu_keyboard())
    await callback.answer()
