from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart, Command
from keyboards.inline import get_main_menu_keyboard
from database import db
import config

router = Router()

@router.message(CommandStart())
async def cmd_start(message: Message):
    user_id = message.from_user.id
    username = message.from_user.username
    first_name = message.from_user.first_name
    
    db.add_user(user_id, username, first_name)
    
    welcome_text = (
        "Привет, любимая! ❤️\n\n"
        "Я твой персональный бот-помощник, пока меня нет.\n"
        "Здесь ты можешь:\n"
        "• Следить за временем до моего возвращения\n"
        "• Вести дневник настроения\n"
        "• Записывать свои мысли и чувства\n"
        "• Отправлять мне весточки\n"
        "• Получать тёплые сообщения и фото\n\n"
        "Нажми на кнопку ниже, чтобы начать!"
    )
    
    await message.answer(welcome_text, reply_markup=get_main_menu_keyboard())

@router.message(Command("help"))
async def cmd_help(message: Message):
    help_text = (
        "📖 Справка по боту:\n\n"
        "/start - Главное меню\n"
        "/help - Эта справка\n"
        "/cancel - Отмена текущего действия\n\n"
        "Функции бота:\n"
        "⏰ Таймер обратного отсчёта\n"
        "😊 Дневник настроения с графиками\n"
        "📝 Личный дневник для записей\n"
        "✉️ Весточки для меня\n"
        "💌 Случайные тёплые фразы"
    )
    await message.answer(help_text)

@router.callback_query(F.data == "main_menu")
async def show_main_menu(callback: CallbackQuery):
    await callback.message.edit_text("Главное меню:", reply_markup=get_main_menu_keyboard())
    await callback.answer()
