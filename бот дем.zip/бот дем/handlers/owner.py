from aiogram import Router, F
from aiogram.filters import StateFilter
from aiogram.types import CallbackQuery, Message
from aiogram.filters import Command
from keyboards.inline import get_main_menu_keyboard
from database import db
import config

router = Router()

@router.message(Command("diary_all"))
async def show_all_diary_entries(message: Message):
    if message.from_user.username != config.OWNER_USERNAME:
        await message.answer("⛔ У тебя нет доступа к этой команде.")
        return
    
    entries = db.get_diary_entries()
    
    if not entries:
        await message.answer("Дневник пуст.")
        return
    
    text = "📓 Все записи из дневника:\n\n"
    for entry in entries:
        text += f"👤 ID: {entry['user_id']}\n"
        text += f"📅 {entry['created_at']}\n"
        text += f"📝 {entry['text']}\n"
        text += "-" * 40 + "\n\n"
    
    await message.answer(text)

@router.message(Command("secret_all"))
async def show_all_secret_messages(message: Message):
    if message.from_user.username != config.OWNER_USERNAME:
        await message.answer("⛔ У тебя нет доступа к этой команде.")
        return
    
    messages = db.get_secret_messages()
    
    if not messages:
        await message.answer("Весточек нет.")
        return
    
    text = "✉️ Все весточки:\n\n"
    for msg in messages:
        text += f"👤 ID: {msg['user_id']}\n"
        text += f"📅 {msg['created_at']}\n"
        if msg['photo_id']:
            text += f"📸 Есть фото\n"
        text += f"📝 {msg['text']}\n"
        text += "-" * 40 + "\n\n"
    
    await message.answer(text)

@router.message(Command("export"))
async def export_data(message: Message):
    if message.from_user.username != config.OWNER_USERNAME:
        await message.answer("⛔ У тебя нет доступа к этой команде.")
        return
    
    diary_entries = db.get_diary_entries()
    secret_messages = db.get_secret_messages()
    
    export_text = "=== ДНЕВНИК ===\n\n"
    for entry in diary_entries:
        export_text += f"ID: {entry['user_id']} | {entry['created_at']}\n"
        export_text += f"{entry['text']}\n\n"
    
    export_text += "\n=== ВЕСТОЧКИ ===\n\n"
    for msg in secret_messages:
        export_text += f"ID: {msg['user_id']} | {msg['created_at']}\n"
        if msg['photo_id']:
            export_text += f"[Фото: {msg['photo_id']}]\n"
        export_text += f"{msg['text']}\n\n"
    
    from aiogram.types import BufferedInputFile
    import io
    
    buffer = io.BytesIO(export_text.encode('utf-8'))
    file = BufferedInputFile(buffer.getvalue(), filename="export.txt")
    
    await message.answer_document(file, caption="📁 Экспорт всех данных")
