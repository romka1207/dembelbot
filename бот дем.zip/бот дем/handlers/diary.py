from aiogram import Router, F
from aiogram.filters import StateFilter
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from keyboards.inline import get_cancel_keyboard, get_main_menu_keyboard
from database import db

router = Router()

class DiaryStates(StatesGroup):
    waiting_for_entry = State()

@router.callback_query(F.data == "diary")
async def request_diary_entry(callback: CallbackQuery, state: FSMContext):
    await state.set_state(DiaryStates.waiting_for_entry)
    await callback.message.edit_text(
        "✍️ Пиши всё, что на душе...\n\n"
        "Твои мысли, чувства, новости — всё сохранится в дневнике ❤️",
        reply_markup=get_cancel_keyboard()
    )
    await callback.answer()

@router.message(StateFilter(DiaryStates.waiting_for_entry))
async def process_diary_entry(message: Message, state: FSMContext):
    user_id = message.from_user.id
    text = message.text
    
    db.add_diary_entry(user_id, text)
    
    await state.clear()
    await message.answer(
        "Запись сохранена в дневник! ❤️\n\n"
        "Спасибо, что поделилась. Я обязательно прочитаю всё, когда вернусь!",
        reply_markup=get_main_menu_keyboard()
    )

@router.callback_query(F.data == "cancel", StateFilter(DiaryStates.waiting_for_entry))
async def cancel_diary_entry(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text("Отменено.", reply_markup=get_main_menu_keyboard())
    await callback.answer()
