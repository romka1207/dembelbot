from aiogram import Router, F
from aiogram.filters import StateFilter
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from keyboards.inline import get_mood_keyboard, get_main_menu_keyboard
from database import db
from utils.charts import create_emoji_calendar, get_mood_by_date
from datetime import datetime

router = Router()

class MoodStates(StatesGroup):
    waiting_for_rating = State()
    waiting_for_date = State()

@router.callback_query(F.data == "mood")
async def request_mood_rating(callback: CallbackQuery, state: FSMContext):
    await state.set_state(MoodStates.waiting_for_rating)
    await callback.message.edit_text(
        "Как у тебя сегодня настроение? Оцени от 1 до 5:",
        reply_markup=get_mood_keyboard()
    )
    await callback.answer()

@router.callback_query(F.data.startswith("mood_"), StateFilter(MoodStates.waiting_for_rating))
async def process_mood_rating(callback: CallbackQuery, state: FSMContext):
    mood = int(callback.data.split("_")[1])
    user_id = callback.from_user.id
    
    db.add_mood_entry(user_id, mood)
    
    mood_emojis = {1: "😢", 2: "🙁", 3: "😐", 4: "🙂", 5: "😍"}
    emoji = mood_emojis.get(mood, "😐")
    
    await state.clear()
    await callback.message.edit_text(
        f"Записано! Твоё настроение: {emoji}\n\nСпасибо, что поделилась! ❤️",
        reply_markup=get_main_menu_keyboard()
    )
    await callback.answer()

@router.callback_query(F.data == "chart")
async def show_mood_calendar(callback: CallbackQuery):
    user_id = callback.from_user.id
    
    mood_data = db.get_mood_entries(user_id, days=365)
    
    calendar_text = create_emoji_calendar(mood_data)
    
    await callback.message.edit_text(
        calendar_text,
        reply_markup=get_main_menu_keyboard()
    )
    await callback.answer()

@router.callback_query(F.data == "mood_by_date")
async def request_date_for_mood(callback: CallbackQuery, state: FSMContext):
    await state.set_state(MoodStates.waiting_for_date)
    await callback.message.edit_text(
        "📅 Введи дату в формате ГГГГ-ММ-ДД\nНапример: 2026-06-08",
        reply_markup=get_main_menu_keyboard()
    )
    await callback.answer()

@router.message(StateFilter(MoodStates.waiting_for_date))
async def show_mood_by_date(message: Message, state: FSMContext):
    user_id = message.from_user.id
    date_str = message.text.strip()
    
    # Валидация даты
    try:
        datetime.strptime(date_str, '%Y-%m-%d')
    except ValueError:
        await message.answer(
            "❌ Неверный формат даты. Используй ГГГГ-ММ-ДД\nНапример: 2026-06-08",
            reply_markup=get_main_menu_keyboard()
        )
        await state.clear()
        return
    
    mood_data = db.get_mood_entries(user_id, days=365)
    mood_text = get_mood_by_date(mood_data, date_str)
    
    await state.clear()
    await message.answer(mood_text, reply_markup=get_main_menu_keyboard())
