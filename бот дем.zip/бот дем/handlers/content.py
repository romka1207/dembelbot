from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.filters import Command
from keyboards.inline import get_main_menu_keyboard
import random
import os
import config
import logging

logger = logging.getLogger(__name__)

router = Router()

PHRASES = [
    "Ты — моё солнце, даже когда тебя не рядом ☀️",
    "Каждый день без тебя — это шаг к нашей встрече 💕",
    "Ты делаешь этот мир лучше просто тем, что существуешь 🌸",
    "Я скучаю по твоей улыбке больше всего на свете 😊",
    "Ты — лучшее, что случилось в моей жизни ❤️",
    "Даже на расстоянии ты рядом с моим сердцем 💓",
    "Твоя сила вдохновляет меня каждый день 💪",
    "Я люблю тебя больше, чем можно выразить словами 💖",
    "Ты — моя мечта, которая стала реальностью ✨",
    "С тобой каждый момент особенный 🌟",
    "Твоя доброта делает мир ярче 🌈",
    "Я считаю дни до нашей встречи ⏰",
    "Ты — мой ангел-хранитель 👼",
    "Твоя красота — не только внешняя, но и душевная 💎",
    "Я благодарен судьбе за то, что ты есть в моей жизни 🙏",
    "Ты — моя мотивация становиться лучше 🚀",
    "Твой голос — моя любимая мелодия 🎵",
    "Ты — причина, по которой я верю в чудеса 🌠",
    "Я люблю каждую твою черточку, каждый твой жест 💕",
    "Ты — мой дом, где бы я ни был 🏠",
    "Ты — моя радость, моя надежда, моя любовь ❤️",
    "С тобой я чувствую себя живым 🌊",
    "Ты — самая прекрасная глава в моей истории 📖",
    "Я ношу тебя в сердце всегда 💝",
    "Ты — мой идеал, которого я даже не искал 💫",
    "Твоя смелость восхищает меня 🦁",
    "Ты — свет в моей темноте 🕯️",
    "Я люблю тебя больше, чем вчера, но меньше, чем завтра 💗",
    "Ты — моя вселенная 🌌",
    "Ты — причина, по которой я просыпаюсь с улыбкой 😄",
    "Ты — моё счастье, упакованное в человека 🎁"
]

COMPLIMENTS = [
    "У тебя невероятно красивые глаза 👀",
    "Твоя улыбка освещает весь мир 😊",
    "Ты очень умная и талантливая 🧠",
    "У тебя доброе и чуткое сердце ❤️",
    "Ты потрясающе выглядишь всегда 💃",
    "Твоя энергия заряжает всех вокруг ⚡",
    "Ты — настоящая красавица 👸",
    "У тебя отличный вкус во всём 🎨",
    "Ты очень сильная и уверенная в себе 💪",
    "Твоя харизма просто магнетическая 🧲",
    "У тебя потрясающее чувство юмора 😄",
    "Ты — воплощение грации и элегантности 🦢",
    "Твоя доброта не знает границ 💖",
    "Ты очень заботливая и внимательная 🤗",
    "У тебя уникальный и прекрасный стиль 👗"
]

QUOTES = [
    "Любовь — это когда ты хочешь, чтобы другому было хорошо, даже если это в ущерб тебе. — Антуан де Сент-Экзюпери",
    "Истинная любовь начинается тогда, когда ничего не нужно взамен, даже понимания. — Вениамин Каверин",
    "Любить — это не значит смотреть друг на друга, это значит смотреть в одном направлении. — Антуан де Сент-Экзюпери",
    "Любовь сильнее смерти и страха смерти. Только ею держится и движется жизнь. — Иван Тургенев",
    "Нет ничего лучше и хуже любви. — Фёдор Достоевский",
    "Любовь — это единственное, что удваивает счастье и делит горе. — Франклин Рузвельт",
    "Любовь — это искусство, и её нужно изучать. — Эрих Фромм",
    "Любовь — это когда ты хочешь, чтобы другой человек был счастлив, даже если ты не часть этого счастья. — Джулия Робертс",
    "Любовь — это не то, что ты ожидаешь получить, а то, что ты готов отдать. — Кэтрин Хепберн",
    "Любовь — это когда ты отдаёшь всё, не ожидая ничего взамен. — Мать Тереза"
]

FUNNY_PHRASES = [
    "Знаешь, я даже скучаю по твоим капризам 😂",
    "Если бы скуча было олимпийским видом спорта, я бы уже был чемпионом 🥇",
    "Ты — единственный человек, которого я готов слушать часами 🗣️",
    "Мой мозг на 90% занят мыслями о тебе 🧠💕",
    "Я как телефон — всегда на связи с тобой 📱",
    "Ты — мой любимый баг в программе жизни 🐛❤️",
    "Если бы ты была WiFi, я бы никогда не отключался 📶",
    "Ты — моя любимая кнопка 'назад' в жизни 🔙",
    "Я как кот — мурлычу, когда думаю о тебе 🐱",
    "Ты — мой личный антидепрессант 💊❤️"
]

@router.callback_query(F.data == "phrase")
async def send_random_phrase(callback: CallbackQuery):
    all_phrases = PHRASES + COMPLIMENTS + QUOTES + FUNNY_PHRASES
    phrase = random.choice(all_phrases)
    
    photos_dir = "data/photos"
    photo_sent = False
    
    if os.path.exists(photos_dir):
        photos = [f for f in os.listdir(photos_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.gif'))]
        if photos:
            photo_path = os.path.join(photos_dir, random.choice(photos))
            try:
                from aiogram.types import FSInputFile
                await callback.message.edit_text("💌 Случайная фраза для тебя:")
                await callback.message.answer_photo(
                    photo=FSInputFile(photo_path),
                    caption=f"{phrase}",
                    reply_markup=get_main_menu_keyboard()
                )
                photo_sent = True
            except Exception as e:
                logger.error(f"Failed to send photo: {e}")
    
    if not photo_sent:
        await callback.message.edit_text(
            f"💌 Случайная фраза для тебя:\n\n{phrase}",
            reply_markup=get_main_menu_keyboard()
        )
    
    await callback.answer()

@router.callback_query(F.data == "photo")
async def send_random_photo(callback: CallbackQuery):
    photos_dir = "data/photos"
    
    if not os.path.exists(photos_dir):
        await callback.message.edit_text(
            "📸 Пока нет фото. Добавь их в папку data/photos/",
            reply_markup=get_main_menu_keyboard()
        )
        await callback.answer()
        return
    
    photos = [f for f in os.listdir(photos_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.gif'))]
    
    if not photos:
        await callback.message.edit_text(
            "📸 Пока нет фото. Добавь их в папку data/photos/",
            reply_markup=get_main_menu_keyboard()
        )
        await callback.answer()
        return
    
    photo_path = os.path.join(photos_dir, random.choice(photos))
    
    await callback.message.edit_text("📸 Случайное фото:")
    try:
        from aiogram.types import FSInputFile
        await callback.message.answer_photo(
            photo=FSInputFile(photo_path),
            caption="Наше фото ❤️",
            reply_markup=get_main_menu_keyboard()
        )
    except Exception as e:
        await callback.message.answer(
            f"Не удалось загрузить фото. Ошибка: {e}",
            reply_markup=get_main_menu_keyboard()
        )
    
    await callback.answer()
