from aiogram import Router, F
from aiogram.types import CallbackQuery
from utils.timer import format_countdown
from keyboards.inline import get_main_menu_keyboard
import logging

logger = logging.getLogger(__name__)

router = Router()

@router.callback_query(F.data == "countdown")
async def show_countdown(callback: CallbackQuery):
    try:
        countdown_text = format_countdown()
        logger.info(f"Countdown text: {countdown_text}")
        await callback.message.edit_text(countdown_text, reply_markup=get_main_menu_keyboard())
    except Exception as e:
        logger.error(f"Ошибка при показе таймера: {e}")
        await callback.message.edit_text(
            f"Ошибка: {e}",
            reply_markup=get_main_menu_keyboard()
        )
    await callback.answer()
